import type { ExpoConfig } from 'expo/config';

/**
 * Expo app configuration.
 *
 * This is a .ts file (not app.json) so we can read environment variables and
 * switch values per build profile. Anything secret belongs in .env / EAS
 * secrets, never in this file — it is committed to git.
 */

/**
 * IMPORTANT: these identifiers are permanent once you publish to the stores.
 * Change them BEFORE your first submission, never after.
 *
 * ── com.pawtrack.app IS NOT AVAILABLE ON APPLE'S SIDE ─────────────────
 *
 * Registering it fails: "The app identifier com.pawtrack.app cannot be
 * registered to your development team because it is not available." Bundle
 * identifiers are globally unique across every Apple developer account, and
 * this one is already claimed by someone else — so this project can never
 * ship under it, whatever happens locally.
 *
 * That decision is not made here. `IOS_BUNDLE_ID` overrides it for a device
 * build so testing is not blocked on choosing the permanent name, and the
 * default is left exactly as it was. Android is untouched: its package name
 * has no such registry and `com.pawtrack.app` is free to keep there, though
 * matching the two is worth doing when the real identifier is picked.
 */
const BUNDLE_ID = 'com.pawtrack.app';
const IOS_BUNDLE_ID = process.env.IOS_BUNDLE_ID ?? BUNDLE_ID;

const config: ExpoConfig = {
  name: 'PawTrack',
  slug: 'pawtrack',
  version: '1.0.0',
  orientation: 'portrait',
  scheme: 'pawtrack', // enables deep links, required by expo-router
  userInterfaceStyle: 'light',

  icon: './assets/icon.png',

  ios: {
    supportsTablet: true,
    bundleIdentifier: IOS_BUNDLE_ID,
    /**
     * The Apple team the app AND its extensions are signed by.
     *
     * Needed because the app is no longer a single target: the Record Seizure
     * widget (targets/seizure/) is a second bundle id, and Xcode will not pick
     * a signing team for an extension on its own. Without this, a local
     * `expo run:ios` fails at the widget target with "Signing for
     * 'SeizureWidget' requires a development team" — the app itself builds
     * fine, which makes it a confusing failure.
     *
     * From the environment because it is account-specific: a fork or a
     * contributor builds under their own team, and hardcoding mine would make
     * this file something every one of them has to edit and remember not to
     * commit. EAS supplies its own credentials and does not need it.
     */
    appleTeamId: process.env.APPLE_TEAM_ID,
    // Sign in with Apple. NOT optional: App Store guideline 4.8 requires an
    // equivalent privacy-preserving option wherever a third-party social login
    // is offered, and this app offers Google. Shipping Google without this is
    // a guaranteed rejection.
    /*
      Disabled only when APPLE_PERSONAL_TEAM=1 — a free Apple team cannot
      provision this capability, and leaving it on makes an on-device build
      fail at signing with a message that names a missing profile rather than
      the capability behind it. Default stays `true`: guideline 4.8 requires
      it wherever Google sign-in is offered, and the flag is local-only so it
      cannot follow a build to EAS. See plugins/withPersonalTeamEntitlements.
    */
    usesAppleSignIn: process.env.APPLE_PERSONAL_TEAM !== '1',
    // iOS shows these strings in the permission dialog. Apple REJECTS apps
    // whose strings are vague, so each one names the concrete user benefit.
    //
    // KEEP ALL THREE. They look like they belong to expo-camera, which has no
    // importers — but they are required by expo-image-picker, which IS used:
    // src/services/videoService.ts calls launchCameraAsync() to record a
    // seizure. iOS hard-crashes an app that touches the camera without a usage
    // string, so deleting these alongside the expo-camera plugin entry would
    // crash the one feature owners use mid-emergency.
    infoPlist: {
      NSCameraUsageDescription:
        "PawTrack uses the camera so you can record video of your dog's seizure to show your veterinarian.",
      NSMicrophoneUsageDescription:
        "PawTrack records audio with seizure videos, because vocalisation can be clinically relevant.",
      NSPhotoLibraryUsageDescription:
        'PawTrack lets you attach a video you already recorded to a seizure record.',
      // ADD-ONLY, and deliberately separate from the string above. Saving a
      // seizure video back to Photos does not require the ability to read the
      // owner's library, and iOS shows a materially gentler prompt for
      // add-only access — so the narrower ask also gets granted more often.
      // expo-media-library is requested with writeOnly: true to match.
      NSPhotoLibraryAddUsageDescription:
        'PawTrack saves seizure videos to your photo library so you can keep them or send them to your veterinarian.',
      // expo-local-authentication, for the OPT-IN app lock in Settings.
      //
      // This is a device lock, not a session policy. It protects the records
      // if someone picks up an unlocked phone, requires no network, and — the
      // reason it is the right tool — it cannot log anyone out at the wrong
      // moment. An app that demands re-authentication at 3am has failed at the
      // one moment it exists for.
      NSFaceIDUsageDescription:
        'PawTrack can use Face ID to unlock your dog\u2019s health records.',
      // NOTE: there is deliberately NO UIBackgroundModes entry here.
      // The seizure timer does not need one — elapsed time is derived from an
      // absolute start timestamp and recomputed the instant the app returns to
      // the foreground, so suspending JS costs nothing. Declaring the `audio`
      // background mode without actually playing audio does not keep the timer
      // running and is a documented App Review rejection (guideline 2.5.4).
    },
  },

  android: {
    package: BUNDLE_ID,
    adaptiveIcon: {
      backgroundColor: '#F6F2EA',
      foregroundImage: './assets/android-icon-foreground.png',
      backgroundImage: './assets/android-icon-background.png',
      monochromeImage: './assets/android-icon-monochrome.png',
    },
    // Same rule as infoPlist above: the first three serve expo-image-picker's
    // camera launch, not expo-camera. VIBRATE serves expo-haptics on the live
    // seizure screen.
    //
    // POST_NOTIFICATIONS is back because medication reminders now exist and
    // schedule notifications — native config lands with the feature that needs
    // it, never ahead of it.
    //
    // SCHEDULE_EXACT_ALARM stays OUT. A daily medication reminder does not need
    // to fire to the second, and it is a policy-restricted permission that
    // requires a Play Console declaration form. An inexact daily alarm is the
    // right trade.
    permissions: [
      'CAMERA',
      'RECORD_AUDIO',
      'READ_MEDIA_VIDEO',
      'POST_NOTIFICATIONS',
      'VIBRATE',
      // Needed only on Android 9 and below, where saving into shared media
      // still goes through the legacy external-storage path. Android 10+ uses
      // scoped storage and ignores it.
      //
      // expo-media-library's plugin declares this itself, UNCAPPED — its
      // withPermissions path writes android:name and nothing else. Listing it
      // here is therefore redundant for presence but useful as the record of
      // why it is in the manifest at all. The maxSdkVersion cap that keeps it
      // off modern devices comes from ./plugins/withCappedLegacyStorage.
      'WRITE_EXTERNAL_STORAGE',
    ],

    /*
      PERMISSIONS THAT MUST NOT SURVIVE INTO THE MANIFEST.

      `permissions` above is additive — it cannot take anything away, and two
      sources add entries we never asked for:

        * Expo's bare-minimum manifest template, which seeds SYSTEM_ALERT_WINDOW
          under a comment literally reading "OPTIONAL PERMISSIONS, REMOVE
          WHATEVER YOU DO NOT NEED" (@expo/config-plugins → withAndroidBaseMods).
        * library manifests merged in by Gradle — expo-image-picker and
          expo-media-library both declare the full READ_MEDIA_* set.

      Each entry here becomes `tools:node="remove"`, so the merged manifest
      comes out without it whoever asked for it.

      ── WHY EACH ONE GOES ──────────────────────────────────────────────

      SYSTEM_ALERT_WINDOW — "draw over other apps". Nothing in this app draws
      an overlay. It is a policy-sensitive permission on Play, and shipping it
      is exactly the over-broad declaration the rule below warns about.

      READ_MEDIA_AUDIO — the app records audio as part of a seizure video
      (RECORD_AUDIO, which stays), but it never READS audio out of the user's
      library. Nothing would break; nothing would use it.

      READ_MEDIA_VISUAL_USER_SELECTED — the Android 14 "Select photos" partial
      grant. Not needed here because both pickers go through the system photo
      picker (expo-image-picker's default), which returns a URI without any
      media permission at all. See the note in docs/SECURITY.md.

      ── WHAT DELIBERATELY STAYS ────────────────────────────────────────

      READ_MEDIA_IMAGES and READ_MEDIA_VIDEO. Both are genuinely used, and it
      is worth writing down which is which so neither gets trimmed later on the
      assumption that this app only handles video:

        images → the dog's profile photo, src/services/dogPhotoService.ts:53,75
        video  → importing a seizure recording, src/services/videoService.ts:188,228
    */
    blockedPermissions: [
      'android.permission.SYSTEM_ALERT_WINDOW',
      'android.permission.READ_MEDIA_AUDIO',
      'android.permission.READ_MEDIA_VISUAL_USER_SELECTED',
    ],
  },

  /**
   * RULE: native configuration lands in the SAME PR as the feature that needs
   * it, never ahead of it. Scaffolding that costs nothing in a web app costs a
   * review cycle in a mobile one — Apple checks that declared permissions
   * correspond to functionality that exists (guideline 5.1.1), and Google Play
   * treats an over-broad Data Safety declaration as a policy violation in the
   * other direction.
   *
   * expo-camera has NO plugin entry and needs none — but it IS imported, and
   * the claim that it has "no importers" was wrong: videoService.ts calls
   * CameraView.getAvailableVideoCodecsAsync() to detect a simulator with no
   * capture device before opening the picker. It needs no plugin because the
   * view is never rendered, only queried. Do not drop the dependency on the
   * assumption that nothing uses it.
   *
   * expo-notifications EARNED ITS ENTRY BACK in the medication-reminder change:
   * src/services/medicationReminders.ts schedules repeating daily reminders.
   *
   * expo-print and expo-sharing are installed but were never plugin-configured,
   * so there is nothing to remove; they earn entries when the vet report ships.
   */
  plugins: [
    /*
      FIRST in this list, which makes it run LAST.
      Expo composes mods by wrapping: the plugin registered last runs first,
      then delegates inward to the ones registered before it. This one deletes
      entitlements that expo-notifications and expo-apple-authentication add,
      so it has to run after both — which means being written before both.
      Registered at the end it ran first, stripped nothing that existed yet,
      and the two keys were added straight back afterwards.
      A no-op unless APPLE_PERSONAL_TEAM=1.
    */
    './plugins/withPersonalTeamEntitlements',

    'expo-router',
    [
      'expo-notifications',
      {
        // Local notifications only — medication reminders. There is no push
        // server; nothing about the dog leaves the device.
        //
        // NOT './assets/icon.png'. Android draws the status-bar icon from the
        // ALPHA CHANNEL alone: every opaque pixel becomes white, every colour
        // is discarded. A full-bleed app icon has no transparency, so it
        // arrived as a solid white square. This asset is the paw silhouette on
        // a transparent field, cropped to fill the 24dp frame — the plugin
        // rescales it into drawable-mdpi…xxxhdpi as `notification_icon`.
        icon: './assets/notification-icon.png',
        // Tints that silhouette and the app name in the banner header.
        color: '#2F7E86',
      },
    ],
    [
      'expo-image-picker',
      {
        photosPermission:
          'PawTrack lets you attach a video you already recorded to a seizure record.',
      },
    ],
    'expo-sqlite',
    [
      'expo-media-library',
      {
        savePhotosPermission:
          'PawTrack saves seizure videos to your photo library so you can keep them or send them to your veterinarian.',
        // We never read the library through this module — video IMPORT goes
        // through expo-image-picker, which has its own narrower prompt. Asking
        // for read access here would be scope we do not use.
        photosPermission:
          'PawTrack saves seizure videos to your photo library so you can keep them or send them to your veterinarian.',
        isAccessMediaLocationEnabled: false,
      },
    ],
    // Playback in the gallery. expo-video replaces expo-av's Video component,
    // which is deprecated — do not add expo-av back for this.
    'expo-video',
    // Session tokens live in the iOS keychain / Android keystore, never in
    // AsyncStorage. These are bearer tokens for veterinary health records and
    // AsyncStorage is plaintext on disk.
    'expo-secure-store',
    'expo-apple-authentication',
    [
      '@react-native-google-signin/google-signin',
      {
        // The REVERSED iOS client id, e.g. com.googleusercontent.apps.123-abc.
        // Read from the environment because it differs per Firebase/GCP
        // project and must not be hardcoded into a committed file.
        iosUrlScheme:
          process.env.GOOGLE_IOS_URL_SCHEME ?? 'com.googleusercontent.apps.PLACEHOLDER',
      },
    ],
    'expo-local-authentication',
    // MUST come after expo-media-library: it caps the legacy storage
    // permissions that plugin adds uncapped. See the file for why.
    './plugins/withCappedLegacyStorage',

    /*
     * The Record Seizure widget, one platform each.
     *
     * Both halves open the same URL — pawtrack://seizure/start, handled by
     * app/seizure/start.tsx — and both are generated at prebuild time because
     * /ios and /android are gitignored build output in this project. Native
     * code committed into either would be deleted by the next
     * `expo prebuild --clean`, silently taking the widget off every home
     * screen at the following release.
     *
     * @bacons/apple-targets links targets/seizure/ as a WidgetKit extension;
     * withSeizureWidget writes the Android AppWidgetProvider and its
     * resources. Neither works in Expo Go — a widget is native code outside
     * the JS bundle, so this needs a development build.
     */
    '@bacons/apple-targets',
    './plugins/withSeizureWidget',
  ],

  experiments: {
    typedRoutes: true, // gives us type-safe router.push() paths
  },

  extra: {
    eas: {
      /**
       * The EAS project this app builds under: @pawtrack2/pawtrack.
       *
       * ── WHY THIS IS COMMITTED AND NOT READ FROM .env ──────────────────
       *
       * It used to be `process.env.EAS_PROJECT_ID ?? undefined`, with a note
       * saying `eas init` would fill it in. Neither half worked:
       *
       *   - `eas init` CANNOT write into a dynamic `app.config.ts`. It edits
       *     `app.json`, which this project does not have.
       *   - `eas-cli` does not load `.env` when it evaluates the config. Only
       *     the Expo dev server does. So putting the id in `.env` left every
       *     `eas` command failing with "EAS project not configured", and the
       *     only thing that worked was prefixing the variable by hand on every
       *     invocation.
       *
       * The id is a PUBLIC identifier — it ships in the app bundle, appears in
       * every EAS build URL, and grants nothing on its own. Committing it is
       * what the Expo docs do and what makes `eas build` work on a fresh
       * clone and in CI without extra setup.
       *
       * The env var still wins when it is set, so a fork can point at its own
       * project without editing this file.
       */
      projectId:
        process.env.EAS_PROJECT_ID ?? '1d820947-6403-4204-a688-da3978a13415',
    },

    /**
     * Supabase connection details.
     *
     * Both of these are PUBLIC by design and safe in a client bundle. The anon
     * key is a signed JWT asserting the `anon` role and nothing more; Row
     * Level Security is what actually protects the data, which is why
     * supabase/tests/rls_smoke_test.sql runs in CI.
     *
     * The SERVICE ROLE key must NEVER appear here, in .env, or anywhere else
     * this file can reach. It bypasses RLS completely. If it ever ships in a
     * build, every account's records are readable by anyone who unzips the
     * app.
     */
    /**
     * Both naming conventions are accepted, EXPO_PUBLIC_ first.
     *
     * Supabase's own Expo quickstart tells you to name these
     * EXPO_PUBLIC_SUPABASE_URL / EXPO_PUBLIC_SUPABASE_ANON_KEY, so that is the
     * name most people will already have in .env. The unprefixed name is kept
     * as a fallback rather than dropped, because silently ignoring a variable
     * someone has clearly set is how you get an app that builds fine, runs
     * fine, and never syncs — with nothing anywhere saying why.
     *
     * Note these are read HERE and passed through `extra`, not read from
     * process.env inside a source file. Metro only inlines EXPO_PUBLIC_* at
     * build time, so a value that is present when you run `expo start` can be
     * undefined at runtime if it is read from the wrong place.
     */
    supabaseUrl:
      process.env.EXPO_PUBLIC_SUPABASE_URL ?? process.env.SUPABASE_URL ?? '',

    /**
     * The client key, under any of the names Supabase's docs have used.
     *
     * Supabase is mid-migration from legacy JWT keys (`anon` / `service_role`,
     * `eyJ…`) to the new API keys (`sb_publishable_…` / `sb_secret_…`), and
     * their guides name the variable differently depending on vintage. Both
     * key types work identically as the second argument to createClient, and
     * both map to the `anon` Postgres role — so RLS is still the thing
     * protecting the data either way.
     *
     * Accepting the realistic set beats one canonical name, because the
     * failure mode of guessing wrong is silent: the app builds, runs, and
     * simply never syncs.
     */
    supabaseAnonKey:
      process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY ??
      process.env.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY ??
      process.env.EXPO_PUBLIC_SUPABASE_KEY ??
      process.env.SUPABASE_ANON_KEY ??
      process.env.SUPABASE_PUBLISHABLE_KEY ??
      process.env.SUPABASE_KEY ??
      '',

    // OAuth client ids for the NATIVE id-token flow. Also public: they
    // identify the app to Google, they do not authorise anything on their own.
    googleWebClientId:
      process.env.EXPO_PUBLIC_GOOGLE_WEB_CLIENT_ID ??
      process.env.GOOGLE_WEB_CLIENT_ID ??
      '',
    googleIosClientId:
      process.env.EXPO_PUBLIC_GOOGLE_IOS_CLIENT_ID ??
      process.env.GOOGLE_IOS_CLIENT_ID ??
      '',
  },
};

export default config;
